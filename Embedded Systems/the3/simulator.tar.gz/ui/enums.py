from enum import IntEnum

class AltitudeZoneState(IntEnum):
    GOOD_STATE = 1
    NEUTRAL_STATE = 0
    BAD_STATE = -1
